import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Linkedin } from "lucide-react";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gray-50 text-gray-800">
      <section className="p-8 text-center bg-blue-900 text-white">
        <h1 className="text-5xl font-bold mb-2">Md Hamidul Islam</h1>
        <p className="text-xl">IT Infrastructure Manager | Cloud & Cybersecurity Specialist</p>
        <div className="flex justify-center gap-4 mt-4">
          <Button variant="outline" asChild>
            <a href="mailto:h.islam24@outlook.com" className="flex items-center gap-2">
              <Mail size={16} /> Email Me
            </a>
          </Button>
          <Button variant="outline" asChild>
            <a href="https://www.linkedin.com/in/hamidul-islam-hamid/" target="_blank" className="flex items-center gap-2">
              <Linkedin size={16} /> LinkedIn
            </a>
          </Button>
        </div>
      </section>
      {/* Full site content goes here */}
    </main>
  );
}